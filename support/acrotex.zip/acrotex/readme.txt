The AcroTeX eDucation Bundle --- D. P. Story
Dated: 03/22/08

The distribution comes in two zip files
1)  acrotex_pack.zip: The package files, the AeB Manual, and the only
    the new example files.
2)  acrotex_exdoc.zip: The full set of documentation (including eforms,
    insdljs, etc) and the full set of example files.

Download only acrotex_pack.zip if you are a user of acrotex in the past,
acrotex_pack.zip contains all the new stuff.

What's New: (03/22/08)
1)  Improved documentation.
    (a) Folded the documentation for the AeB JavaScript Library
        (which was just a .dtx) into the AeB Manual. The AeB JavaScript
        Library (dljslib) has been improved, some bugs fixed,
        documentation enhanced.
    (b) Combined the documentation for the eforms package with the
        documentation for the indljs package (formerly available in .dtx
        form) into one manual, the eformman.pdf. All documentation
        is improved and expanded.

2) Web Package: Added three new options unicode, useui and turkish.
    (a) The unicode option is passed to hyperref. Now eforms uses
        the unicode capability of hyperref. This option is a
        convenience option since eforms is not called explicitly
        when using the Web package.
    (b) The useui option is passed to the eforms package, see below.
    (c) The new language option, turkish, requires the unicode
        option, which is silently called.

3) Exerquiz Package: Same three options as Web

4) eforms Package.
    (a) The eforms package can now use the \pdfstringdef command of
        hyperref to write unicode, if the unicode option of hyperref
        has been taken.  This means that when you create your text
        fields, you can use LaTeX notation to initialize any
        elements of a field that can take unicode.
    (b) The new option useui inputs the xkeyval package, and defines
        a number of key-value pairs used for setting the appearance
        state of fields and links, and for setting actions. The
        useui system is compatible with the default system, and they
        work together.
    (c) Documentation of links. Links have been around in the eforms
        package but not documented. With a population of size one
        wishing for it, I've made it so.

Contents:
0)  acrotex.ins --- installation batch file for the AcroTeX Bundle.
1)  web.dtx --- a package that redefines the page layout to
    more web-friendly dimensions.  Also defines a new table of
    contents, navigational aids.  Driver options are for dvipsone
    (by Y&Y), dvips, pdftex, dvipdfm and dviwindo.  There are
    language options for dutch, french, german, italian.
     norsk, russian spanish, dansk, polish, finnish, turkish.
2)  exerquiz.dtx --- a package that defines three new environments:
    (1) exercise, for creating online exercises with solutions
    linked to the questions; (2) shortquiz, for creating multiple
    choice quizzes with immediate response, with options to see the
    solution; (3) quiz, longer quizzes that are graded with
    JavaScript, the quizzes can optionally be corrected by
    JavaScript as well.
3)  eForms.dtx -- this package give fairly complete support of PDF forms. The
    documentation for this package is eformman.pdf
4)  insdljs.dtx --- a package for inserting document level JavaScripts
    from a LaTeX source. Command for defining open page actions and an
    environment for defining JavaScript.
5)  dljslib.dtx --- A library of JavaScript functions for modifying the way
    in which Exerquiz processes an answer.
6)  eq_pdfs.zip -- this zip file contains a file eq_pdfs.tex that
    demonstrates that exerquiz works with pdfscreen.
7)  aeb_man.pdf --- the manual of usage for web/exerquiz packages.
8)  eformman.pdf --- the manual that describes eForm support
9) eq2dbman.pdf --- manual of usage for the eq2db Package and
    accompanying scripts.


Installation Instructions:
Create a directory in the search path of your LaTeX installation called
acrotex, and unzip the acrotex.zip package.  Install the AcroTeX
Bundle by executing the command: latex acrotex.ins. The eq2db Package (optional)
can be installed with the command: latex eq2db.ins.

Now try LaTeXing the file webeqtst.tex, with the appropriate driver
option set: E.g.,
\usepackage[dvipsone]{web}
\usepackage[dvips]{web}
\usepackage[pdftex]{web}
\usepackage[dvipdfm]{web}

Hopefully everything will work correctly.

If you want to do something fancy with eForms, review the eformman.pdf.
If you are interested in online quizzing, see eq2dbman.pdf.

Let me know if there are problems or suggested features.  e-mail
me at dpstory@uakron.edu or dpstory@acrotex.net.

I maintain a web site featuring TeX/LaTeX/PDF stuff called
AcroTeX (www.math.uakron.edu/~dpstory/acrotex.html).  There you
will find the home web page of the AcroTeX eDucation Bundle.
(www.math.uakron.edu/~dpstory/webeq.html).

I also have a web site www.acrotex.net, where you can get the latest
versions, and contribute to the AcroTeX Forum.

Now, I simply must get back to my retirement.

D. P. Story
www.acrotex.net
dpstory@uakron.edu
dpstory@acrotex.net
03/22/08
