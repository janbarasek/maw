OVERVIEW:

These are TrueType versions of the TeX Computer Modern fonts.
They were made available by BaKoMa on the CTAN site at

  http://www.ctan.org/tex-archive/fonts/cm/ps-type1/bakoma/

which includes the complete TeX font set.  This archive only
includes the six fonts needed by that jsMath package for
displaying mathematics on the web.  JsMath can be found at

  http://www.math.union.edu/locate/jsMath

The BaKoMa copyright notice is in the BaKoMa-CM.fonts
file in this directory.


INSTALLATION:

To install these on a Macintosh running OS X (10.2 or later),
simply drag the .ttf files to your Library/Fonts folder.
That's it.  The fonts should now be available to your web
browser (you may need to restart the browser if it is already
running).

For the PC, go to the  Settings menu of the Start menu at the
bottom left of the screen, and choose Control Panels, and then
click on the Fonts icon.  You should get a window containing
all your installed fonts.  Simply drag the .ttf files to that
window, and the fonts will be installed.
